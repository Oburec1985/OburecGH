
  XNetDetect - v2.1 (C)2007-2008, XCRYSoft
===========================================


  Installation
---------------
  1) Unzip all files;
  2) Add "XNetDetect_v2.pas" into a package and compile it;
  3) Include the path of "XNetDetect_v2.pas" into the library path.


  License
---------------

  This software is provided "as-is," without any express or implied warranty. In no event shall the author be held liable for any damages arising from the use of this software.

  This component is FREEWARE, so you may distribute it freely as long as you comply that XCRYSoft is the author of this component.

  If you want to modify it, then you must notify our support at: support@xcrysoft.com


  Contact
---------------

  support@xcrysoft.com