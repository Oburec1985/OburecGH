These DLLs belong to DelphiZip
The whole package (including) DLLs can be obtained from

  http://www.geocities.com/SiliconValley/Orchard/8607/
  http://members.tripod.lycos.nl/Vleghert/

At the time of writing this, I was advised by the author
of the package (Chris Vleghert; cvleghrt@worldonline.nl)
to use the latest betas which were highly liklely
to make the relase.

Here are the actual file URLs

For Delphi source (and compiled DLLs)
http://www.geocities.com/SiliconValley/Orchard/8607/beta/dz-del160.zip

For Delphi Help file
http://www.geocities.com/SiliconValley/Orchard/8607/beta/zipmst16.zip

You might like to get DLLs compiled with Intel compiler (they might
be faster)
http://www.geocities.com/SiliconValley/Orchard/8607/in-dlls15.zip