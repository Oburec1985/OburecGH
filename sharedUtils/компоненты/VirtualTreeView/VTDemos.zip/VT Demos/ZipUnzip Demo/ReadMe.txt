

This source is intended to be a demonstration of use of 2 components:

Since the latest is always available at the authors' sites, I have not
included any source code for the components themselves. If you wish
to compile this code, I advise you to check with the sites listed
and download the relevant code. 

Here are the components --Alphabetically listed by VCL name.

DelphiZip v1.6 (or above?)
  http://www.geocities.com/SiliconValley/Orchard/8607/
  http://members.tripod.lycos.nl/Vleghert/
  Chris Vleghert
  cvleghrt@worldonline.nl
  
  BTW, I have included the DLLs that are necessary to
  run this demo. Please either put them in the same
  directory as the ZipDemo1.exe or in the <windows>\System32
  directory.


ImagelistEx (System ImageList; TImageList derivative)
  Werner Lehmann <wl@bwl.uni-kiel.de>
  No web site given. As a result, I have included it in 
  this zip file (i.e. ImagelistEx.pas)

VirtualTreeView v2.3 (or above?)
  http://www.lischke-online.de
  Dipl. Ing. Mike Lischke for
  public@lischke-online.de


I have modified the Demo1 in DelphiZip to use VirtualTreeView,
and added a few frills. The paragraph below is from DelphiZip:

   This is a very complete File Manager type of program that 
   lets you create archives, view archives, extract files, etc.  
   It can also turn .zip files into .exe files (and vice-versa). 
   This program does NOT let you create .EXE files directly; 
   see the documentation for DelphiZip.

While I believe it works, you are strongly advised to test it 
for yourself. In other words, usual disclaimers apply.

My portion of this code is public domain. For those belonging 
to other authors, please refer to their respective copyright 
clauses.

adembaba@excite.com
