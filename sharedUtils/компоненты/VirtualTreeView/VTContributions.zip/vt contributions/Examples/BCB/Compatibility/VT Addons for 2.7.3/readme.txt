VSTEdit, MFEdit 1.0.2beta
VirtualTreesEx downloaded 2001-10-15
VirtualDBTree, downloaded 2001-10-25

If you have trouble installing related to VCLDB50.bpi, 
1. ignore the errors,
2. choose Project/Build VT_Addons, then File/Close All,
3. open the VT_Addons.bpk again and
4. install.

milan_va@seznam.cz

Changes from official versions:
  As VSTEdit seems not to be updated any more,
    I have changed PrepareEdit signature to keep
    it compatible with VT 2.6.11.