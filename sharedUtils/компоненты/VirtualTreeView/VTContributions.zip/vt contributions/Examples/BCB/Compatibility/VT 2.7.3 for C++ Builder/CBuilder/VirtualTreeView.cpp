//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("VirtualTreeView.res");
USEUNIT("..\VirtualTrees.pas");
USERES("..\VirtualTrees.dcr");
USEUNIT("..\JwaUxTheme.pas");
USEUNIT("..\JwaTmSchema.pas");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("VCLX50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------

