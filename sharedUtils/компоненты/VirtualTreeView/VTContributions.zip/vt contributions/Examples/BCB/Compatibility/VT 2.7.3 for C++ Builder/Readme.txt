1. Unzip the archive somewhere, in a directory named e.g. VirtualTreeView
2. Replace zero-sized files with original versions
3. create directory $(BCB)\Projects\Bpl and
                    $(BCB)\Projects\Intermed
4. move "clearVT.bat" to $(BCB)\Projects and run it (before every compilation)
5. Check if you have C:\Program Files\Borland\CBuilder5\Projects\Bpl in your system path
  (use "path" in DOS prompt), if it is not there add it to autoexec.bat (in Win98) or
  in Start/Settings/Control Panels/System/Details/Environment Variables (in W2K,
  translated from Czech back to English, so...)
6. Compile VirtualTreeView.bpk
7. Compile and Install VirtualTreeViewD.bpk

----------WARNING----------
For versions 2.7.3 and above, you will have to add the path to
VirtualTreeView\CBuilder subdirectory to all your projects.

If you have any problems, please tell me at

               milan_va@seznam.cz

Files modified from official versions:
  for 2.7.3: VirtualTrees.pas, VirtualTreesReg.pas, Compilers.inc, JwaUxTheme.pas, JwaTmSchema.pas




If you have problems like

[Linker Fatal Error] Fatal: Unable to open file 'VIRTUALTREEVIEWD.LIB'

it means I have forgotten to modify these lines in VirtualTreeView.bpk:
    <LIBRARIES value=""/>
    <SPARELIBS value="VCL50.lib VCLX50.lib"/>
Some other libraries are automatically added to this,
and very often I forget to remove them. I am sorry for this.
