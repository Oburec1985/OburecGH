MF Editor components and a editor link component for VirtualStringTree
Version 1.0.2 Beta
Copyright (c) 2001 Manfred Fuchs



Description
-----------

1.  Add the needed MF Editors to your form and set Visible := False.

2.  Add one ore more TVSTEditor components to your form.

3.  Add the MF Editors in the property fields.

4.  Set the OnCreateEditor event of your VirtualStringTree.

5.  Fill OnCreateEditor() with code.
    Example:
        Data := Sender.GetNodeData( Node );
        with Data^. do
        begin
          case <what editor is needed> of
            <need string editor>:
              VSTEditor.LinkEditor(EditLink,<string value>);
            <need string editor with button>:
              VSTEditor.LinkButtonEditor(EditLink,<string value>);
            <need combo editor>:
              VSTEditor.LinkComboEditor(EditLink,<string value>);
            <need numeric editor>:
              VSTEditor.LinkNumEditor(EditLink,<numeric value>);
            <need datetime editor>:
              VSTEditor.LinkDateTimeEditor(EditLink,<date value>,<time value>);
          end;
        end;

6.  Set the OnNewText event of your VirtualStringTree.

7.  Fill OnNewText() with code. After editing the appropriate editor have
    the new data value.
    Example:
        Data := Sender.GetNodeData( Node );
        with Data^. do
        begin
          case <what editor is used> of
            <string editor>,
            <string editor with button>,
            <combo editor>:
              <string value> := Text;
            <numeric editor>:
              <numeric value> := VSTEditor.NumEditor.Value;
            <datetime editor>:
              <date value> := VSTEditor.DateTimeEditor.Date;
              or
              <time value> := VSTEditor.DateTimeEditor.Time;
          end;
        end;
