//---------------------------------------------------------------------------
#include <vcl.h>
#include "VirtualTrees.hpp"
#include "Printers.hpp"
//---------------------------------------------------------------------------
// In the .h-file :
void __fastcall PrintVTree(TVirtualStringTree *tree,TPrinter *Prt);
void __fastcall PrtStretchDrawDIB(Graphics::TCanvas *DestCanvas, int x, int y, int Width, int Height, Graphics::TBitmap* SourceBitmap);

//---------------------------------------------------------------------------
// Remember to publish Color (from TObject) and to make
// PaintTree() a public method, otherwise the code below won't work...
//
// I have only tested and used this solution with
// VirtualTrees Version 2.4.23.
//
// Anybody might use this code as he/she see fit.
//
// Mathias Thorell, Tias@m.cl
//
//---------------------------------------------------------------------------
void __fastcall PrintVTree(TVirtualStringTree *tree,TPrinter *Prt)
{
  AnsiString OldFont; // Remembers the Printer Font
  TRect ImgRect,      // Describes the dimensions of Img
        TreeRect,     // The total VTree dimensions
        DestRect,     // Dimensions of PrtImg
        SrcRect;      // Clip dimensions from Img -> PrtImg
  TPoint p;           // Used by PaintTree)(
  TPaintOptions po;   // Used by PaintTree()
  TImage *Img,           // Complete Tree is drawn to this TImage
         *PrtImg = NULL; // This is the TImage that gets printed
  TColor OldCol;      // Remembers the VTree Color
  int pTxtHeight,     // Height of font in the TPrinter::Canvas
      vTxtHeight,     // Height of font in the VTree Canvas
      vPageHeight,    // Printer height in VTree resolution
      PageNum,        // # of pages (except the occasional last one)
      Page;           // Loop counter
  float Scale = 1.0;  // Scale factor between Printer Canvas and VTree Canvas

  if (!Prt || !tree) return;

  // Clear the paint options
  po.Clear();

  // Remember the Printer Font
  OldFont = Prt->Canvas->Font->Name;

  // Let the Printer use the same font as the VTree (maybe should be an Assign() ?)
  Prt->Canvas->Font->Name = tree->Font->Name;

  // Create an image that will hold the complete VTree
  Img  = new TImage(NULL);
  Img->Visible = false;

  TreeRect = tree->GetTreeRect();
  Img->Width  = TreeRect.Right  - TreeRect.Left;
  Img->Height = TreeRect.Bottom - TreeRect.Top;
  Img->Picture->Bitmap->Width  = Img->Width;
  Img->Picture->Bitmap->Height = Img->Height;

  p.x = 0;
  p.y = 0;
  ImgRect.Left = 0;
  ImgRect.Top  = 0;
  ImgRect.Right  = Img->Width  - 1;
  ImgRect.Bottom = Img->Height - 1;

  // (Force the background to white color during the rendering)
  OldCol = tree->Color;
  tree->Color = clWhite;
  tree->PaintTree(Img->Canvas,ImgRect,p,po);
  tree->Color = OldCol;

  // Activate the printer
  Prt->BeginDoc();

  // Now we can calculate the scaling :
  pTxtHeight = Prt->Canvas->TextHeight("Tj");
  vTxtHeight = tree->Canvas->TextHeight("Tj");

  Scale = (float)pTxtHeight / (float)vTxtHeight;

  if (ImgRect.Right * Scale <= Prt->PageWidth && ImgRect.Bottom * Scale <= Prt->PageHeight)
  {
    // The whole tree fits on one page (after it's scaled up) :
    PrtStretchDrawDIB(Prt->Canvas,0,0,ImgRect.Right * Scale,ImgRect.Bottom * Scale,Img->Picture->Bitmap);
  }
  else
  {
    // We have to split it up in more than one page :
    if (ImgRect.Bottom * Scale > Prt->PageHeight)
    {
      // Ok, have to print more than one page here, splitted vertically :

      // Create an Image that has the same dimensions as the Printer Canvas but
      // scaled to the VTree resolution :
      PrtImg  = new TImage(NULL);
      PrtImg->Visible = false;

      vPageHeight = (int)((float)Prt->PageHeight / Scale);
      PageNum = Img->Height / vPageHeight;

      PrtImg->Width  = Img->Width;
      PrtImg->Height = vPageHeight;
      PrtImg->Picture->Bitmap->Width  = PrtImg->Width;
      PrtImg->Picture->Bitmap->Height = PrtImg->Height;

      for (Page = 0;Page < PageNum;Page++)
      {
        DestRect.Left = 0;
        DestRect.Top  = 0;
        DestRect.Right  = PrtImg->Width;
        DestRect.Bottom = PrtImg->Height;

        SrcRect.Left = 0;
        SrcRect.Top  = vPageHeight * Page;
        SrcRect.Right  = PrtImg->Width;
        SrcRect.Bottom = SrcRect.Top + vPageHeight;

        PrtImg->Canvas->CopyRect(DestRect,Img->Canvas,SrcRect);
        PrtStretchDrawDIB(Prt->Canvas,0,0,Img->Width * Scale,Prt->PageHeight - 1,PrtImg->Picture->Bitmap);

        if (Page != PageNum - 1)
          Prt->NewPage();
      }

      // Check if there's some part at the end that needs printing :
      if (Img->Height > SrcRect.Bottom)
      {
        Page++;
        Prt->NewPage();

        DestRect.Bottom = Img->Height - SrcRect.Bottom;

        SrcRect.Left   = 0;
        SrcRect.Top    = SrcRect.Bottom + 1;
        SrcRect.Right  = PrtImg->Width;
        SrcRect.Bottom = Img->Height - 1;

        PrtImg->Height = DestRect.Bottom;
        PrtImg->Picture->Bitmap->Height = PrtImg->Height;
        PrtImg->Canvas->CopyRect(DestRect,Img->Canvas,SrcRect);
        PrtStretchDrawDIB(Prt->Canvas,0,0,Img->Width * Scale,DestRect.Bottom * Scale,PrtImg->Picture->Bitmap);
      }
    }
    else
    {
      // Here is the place to make some intelligent splitting because the VTree
      // is to wide for the printer Canvas.
      // This is never the case in my app(s), so there's no point for me to
      // implement it...
      PrtStretchDrawDIB(Prt->Canvas,0,0,Prt->PageWidth - 1,Prt->PageHeight - 1,Img->Picture->Bitmap);
    }
  }

  Prt->Canvas->Font->Name = OldFont;
  Prt->EndDoc();

  // Cleanup :
  if (PrtImg) delete PrtImg;
  delete Img;

}
//---------------------------------------------------------------------------
//
// This routine was posted by Robert Dunn in the
// borland.public.cppbuilder.graphics NewsGroup some time ago...
//
//---------------------------------------------------------------------------
void __fastcall PrtStretchDrawDIB(Graphics::TCanvas *DestCanvas, int x, int y, int Width, int Height, Graphics::TBitmap* SourceBitmap)
{
  long int OriginalWidth;
  HDC DC;
  DWord IsPaletteDevice;
  DWord IsDestPaletteDevice;
  int BitmapInfoSize;
  tagBITMAPINFO *lpBitmapInfo;
  HBITMAP hBm;
  HPALETTE hPal;
  HPALETTE OldPal;
  unsigned char *Bits;
  int NumPalEntries;
  Windows::TPaletteEntry *lPPalEntriesArray;
  HDC FCompHDC;

  //Save the original width of the bitmap
  OriginalWidth = SourceBitmap->Width;

  //use screen's DC
  FCompHDC = GetDC(0);

  //Are we a palette device?
  if ((GetDeviceCaps(FCompHDC, RASTERCAPS) &  RC_PALETTE) == RC_PALETTE)
  {
    IsPaletteDevice = true;
  }
  else IsPaletteDevice = false;

  //Give back the screen dc
  ReleaseDC(0, FCompHDC);

  //Allocate the BitmapInfo structure
  if (IsPaletteDevice == true)
  {
    BitmapInfoSize = sizeof(TBitmapInfo) + (sizeof(RGBQUAD) * 255);
  }
  else BitmapInfoSize = sizeof(TBitmapInfo);

  lpBitmapInfo  = (tagBITMAPINFO*) new char[BitmapInfoSize];

  //Zero out the BitmapInfo structure
  ZeroMemory(lpBitmapInfo, BitmapInfoSize);

  //Fill in the BitmapInfo structure
  lpBitmapInfo->bmiHeader.biSize = sizeof(TBitmapInfoHeader);
  lpBitmapInfo->bmiHeader.biWidth = OriginalWidth;
  lpBitmapInfo->bmiHeader.biHeight = SourceBitmap->Height;
  lpBitmapInfo->bmiHeader.biPlanes = 1;

  if (IsPaletteDevice == true) lpBitmapInfo->bmiHeader.biBitCount = 8;
  else lpBitmapInfo->bmiHeader.biBitCount = 24;

  lpBitmapInfo->bmiHeader.biCompression = BI_RGB;
  lpBitmapInfo->bmiHeader.biSizeImage = ((lpBitmapInfo->bmiHeader.biWidth *
    (long int)(lpBitmapInfo->bmiHeader.biBitCount)) / 8) *
    lpBitmapInfo->bmiHeader.biHeight;

  lpBitmapInfo->bmiHeader.biXPelsPerMeter = 0;
  lpBitmapInfo->bmiHeader.biYPelsPerMeter = 0;

  if (IsPaletteDevice == true)
  {
    lpBitmapInfo->bmiHeader.biClrUsed = 256;
    lpBitmapInfo->bmiHeader.biClrImportant = 256;
  }
  else
  {
    lpBitmapInfo->bmiHeader.biClrUsed = 0;
    lpBitmapInfo->bmiHeader.biClrImportant = 0;
  }

  //Take ownership of the bitmap handle and palette
  hBm = SourceBitmap->ReleaseHandle();
  hPal = SourceBitmap->ReleasePalette();

  //use screen's DC
  FCompHDC = GetDC(0);

  if (IsPaletteDevice == true)
  {
    //If we are using a palette, it must be
    //selected into the dc during the conversion
    OldPal = SelectPalette(FCompHDC, hPal, true);

    //Realize the palette
    RealizePalette(FCompHDC);
  }

  //Tell GetDiBits to fill in the rest of the bitmap info structure
  GetDIBits(SourceBitmap->Canvas->Handle, hBm,
    0, lpBitmapInfo->bmiHeader.biHeight,
    NULL, lpBitmapInfo, DIB_RGB_COLORS);

  //Allocate memory for the Bits
  Bits = new unsigned char[lpBitmapInfo->bmiHeader.biSizeImage];

  //Get the bits
  GetDIBits(SourceBitmap->Canvas->Handle, hBm,
    0, lpBitmapInfo->bmiHeader.biHeight,
    Bits, lpBitmapInfo, DIB_RGB_COLORS);

  if (IsPaletteDevice == true)
  {
    //Lets fix up the color table for buggy video drivers
    lPPalEntriesArray = new TPaletteEntry[256];
    NumPalEntries = GetSystemPaletteEntries(FCompHDC, 0, 256, lPPalEntriesArray);

    for (int i = 0; i < NumPalEntries; i++)
    {
      lpBitmapInfo->bmiColors[i].rgbRed = lPPalEntriesArray[i].peRed;
      lpBitmapInfo->bmiColors[i].rgbGreen = lPPalEntriesArray[i].peGreen;
      lpBitmapInfo->bmiColors[i].rgbBlue = lPPalEntriesArray[i].peBlue;
    }

    delete lPPalEntriesArray;
  }

  if (IsPaletteDevice == true)
  {
    //Select the old palette back in
    SelectPalette(FCompHDC, OldPal, true);

    //Realize the old palette
    RealizePalette(FCompHDC);
  }

  //Give back the screen dc
  ReleaseDC(0, FCompHDC);

  //Is the Dest dc a palette device?
  if ((GetDeviceCaps(DestCanvas->Handle, RASTERCAPS) &  RC_PALETTE) == RC_PALETTE)
  {
    IsPaletteDevice = true;
  }
  else IsPaletteDevice = false;

  if (IsPaletteDevice == true)
  {
    //if we are using a palette, it must be
    //selected into the dc during the conversion
    OldPal = SelectPalette(DestCanvas->Handle, hPal, true);

    //Realize the palette
    RealizePalette(DestCanvas->Handle);
  }

  //Do the blt
  StretchDIBits(DestCanvas->Handle, x, y, Width, Height, 0, 0, OriginalWidth,
    lpBitmapInfo->bmiHeader.biHeight, Bits, lpBitmapInfo,
    DIB_RGB_COLORS, SRCCOPY);

  if (IsDestPaletteDevice == true)
  {
    //Select the old palette back in}
    SelectPalette(DestCanvas->Handle, OldPal, true);

    //Realize the old palette
    RealizePalette(DestCanvas->Handle);
  }

  //De-Allocate the Dib Bits
  delete [] Bits;

  //De-Allocate the BitmapInfo
  delete [] lpBitmapInfo;

  //Set the ownership of the bimap handles back to the bitmap
  SourceBitmap->Handle = hBm;
  SourceBitmap->Palette = hPal;
}
//---------------------------------------------------------------------------

