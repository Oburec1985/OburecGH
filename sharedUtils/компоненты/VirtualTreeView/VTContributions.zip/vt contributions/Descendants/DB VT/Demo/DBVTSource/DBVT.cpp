//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("DBVT.res");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("VirtualTreeView.bpi");
USEUNIT("BaseVirtualDBTree.cpp");
USEUNIT("CustomSimpleVirtualDBTree.cpp");
USEPACKAGE("VCLDB50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
  return 1;
}
//---------------------------------------------------------------------------
