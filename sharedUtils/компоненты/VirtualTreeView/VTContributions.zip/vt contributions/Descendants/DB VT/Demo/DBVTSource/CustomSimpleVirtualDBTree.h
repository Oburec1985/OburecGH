//------------------------------------------------------------------------------

#ifndef CustomSimpleVirtualDBTreeH
#define CustomSimpleVirtualDBTreeH
//------------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include <DB.hpp>

#include "VirtualTrees.hpp"
#include "BaseVirtualDBTree.h"

//------------------------------------------------------------------------------
// ��������� TCustomSimpleVirtualDBTree
// ��������� ��������� ����������������:
//  - ��������� ���� ��������� � ������� �������,
//  - ����� �������� ��� ���������������� ����.
//
class PACKAGE TCustomSimpleVirtualDBTree : public TBaseVirtualDBTree
{
  private:
    // ���� � �������
    TField*     FViewField;
    AnsiString  FViewFieldName;

    void __fastcall SetViewFieldName(AnsiString value);

  protected:
    // �������������� ������� �������
    virtual void __fastcall DoOpeningDataSet(bool& Allow);
    virtual void __fastcall DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow);

    virtual void __fastcall InitFields();
    virtual void __fastcall ResetFields();

  public:
    __fastcall TCustomSimpleVirtualDBTree(TComponent* Owner);

    __property TField*    ViewField     = { read=FViewField };
    __property AnsiString ViewFieldName = { read=FViewFieldName, write=SetViewFieldName };
};

//------------------------------------------------------------------------------
// ��������� TCustomCheckVirtualDBTree
// ��������� ��������� ����������������:
//  - ��������� CheckBox,
//  - �������������� �������� ������ ��� ���������� ���������� ���������.
//    ����������� ������ ID (������ ����� ������� ����� ��������� ���
//    ��������������� �������),
//  - ����� ��������� ������ ���������� ��������� ��� ����� ������,
//  - ������ �� ��������������, TrackChanges = false?
//

//------------------------------------------------------------------------------
// ���������� ������ ����������
//
class PACKAGE TCheckDataLink;

class PACKAGE TCustomDBCheckVirtualDBTree : public TCustomSimpleVirtualDBTree
{
  friend
    class TCheckDataLink;

  private:
    // ����� �� ������ ���������� ������
    TCheckDataLink*   FCheckDataLink;
    AnsiString        FResultFieldName;
    TField*           FResultField;

    // ������������� ��������� ������
    void __fastcall SetCheckDataSource(TDataSource* value);
    TDataSource* __fastcall GetCheckDataSource();

    void __fastcall SetResultFieldName(AnsiString value);
    TStringList* __fastcall GetCheckList();

  protected:
    // ������� �� ��������/ �������� ���������
    virtual void __fastcall CheckDataLinkActiveChanged();

    // ������� �� �������� ��������� ������
    virtual void __fastcall Notification(TComponent* AComponent, TOperation Operation);
    virtual void __fastcall DoOpeningDataSet(bool& Allow);

    DYNAMIC bool __fastcall DoChecking(PVirtualNode Node, TCheckState NewCheckState);
    DYNAMIC void __fastcall DoChecked(PVirtualNode Node);
    virtual void __fastcall DoReadNodeFromDB(PVirtualNode Node);

  public:
    __fastcall TCustomDBCheckVirtualDBTree(TComponent* Owner);
    virtual __fastcall ~TCustomDBCheckVirtualDBTree();

    __property TStringList* CheckList = {read = GetCheckList };

    __property TDataSource*       CheckDataSource   = { read=GetCheckDataSource,  write=SetCheckDataSource };
    __property AnsiString         ResultFieldName   = { read=FResultFieldName,    write=SetResultFieldName };
    __property TField*            ResultField       = { read=FResultField };
};

//------------------------------------------------------------------------------
// ����� TCheckDataLink - ����� �� ������ ���������� ������
//
class PACKAGE TCheckDataLink : public TDataLink
{
  private:
    TCustomDBCheckVirtualDBTree* FTree;

  public:
    __fastcall TCheckDataLink(TCustomDBCheckVirtualDBTree* ATree);

  protected:
    virtual void __fastcall ActiveChanged();
};

//==============================================================================
class PACKAGE TCustomCheckVirtualDBTree : public TCustomSimpleVirtualDBTree
{
  private:
    TStringList* FList;

    void    __fastcall SetCheckList(TStringList* value);
    TStringList*  __fastcall GetCheckList();

  protected:

    DYNAMIC void __fastcall DoChecked(PVirtualNode Node);
    virtual void __fastcall DoReadNodeFromDB(PVirtualNode Node);

  public:
    __fastcall TCustomCheckVirtualDBTree(TComponent* Owner);
    virtual __fastcall ~TCustomCheckVirtualDBTree();

    __property TStringList* CheckList = { read = GetCheckList, write = SetCheckList };
};

//------------------------------------------------------------------------------
// ��������� TSimpleVirtualDBTree
//  - ��������� ���������� �������� ������������� ��
//
#pragma packed(push, 1)
struct TSimpleData
{
  WideString Text;
};
#pragma packed(pop)

class PACKAGE TSimpleVirtualDBTree : public TCustomSimpleVirtualDBTree
{
  private:
    void        __fastcall SetNodeText(PVirtualNode Node, WideString value);
    WideString  __fastcall GetNodeText(PVirtualNode Node);

  protected:
    virtual void __fastcall DoReadNodeFromDB(PVirtualNode Node);
    virtual void __fastcall DoNodeDataChanged(PVirtualNode Node, TField* Field, bool& UpdateNode);
    virtual void __fastcall DoGetText(PVirtualNode Node, int Column, TVSTTextType TextType, WideString& Text);
	  virtual void __fastcall DoNewText(PVirtualNode Node, int Column, WideString Text);
    virtual void __fastcall DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow);
    virtual int  __fastcall DoCompare(PVirtualNode Node1, PVirtualNode Node2, int Column);

  public:
    __fastcall TSimpleVirtualDBTree(TComponent* Owner);

    __property WideString NodeText[PVirtualNode Node] = { read=GetNodeText, write=SetNodeText };


  __published:

    __property OnOpeningDataSet;
    __property OnWritingDataSet;
    __property OnReadPathFromDB;
    __property OnWritePathToDB;

    __property ViewFieldName;
    __property KeyFieldName;
    __property ParentFieldName;
    __property PathFieldName;
    __property LevelFieldName;

    __property DataSource;
    __property DBOptions;


    __property Align ;
	  __property Alignment ;
	  __property Anchors ;
	  __property AutoExpandDelay ;
	  __property AutoScrollDelay ;
	  __property AutoScrollInterval ;
	  __property Background ;
	  __property BiDiMode ;
	  __property BevelEdges ;
	  __property BevelInner ;
	  __property BevelOuter ;
	  __property BevelKind ;
	  __property BevelWidth ;
	  __property BorderStyle ;
	  __property ButtonStyle ;
	  __property BorderWidth ;
	  __property ChangeDelay ;
	  __property CheckImageKind ;
	  __property Color ;
	  __property Colors ;
	  __property Ctl3D ;
	  __property Constraints ;
	  __property CustomCheckImages ;
	  __property DefaultNodeHeight ;
	  __property DefaultPasteMode ;
	  __property DefaultText ;
	  __property DragHeight ;
	  __property DragKind ;
	  __property DragImageKind ;
	  __property DragMode ;
	  __property DragOperations ;
	  __property DragType ;
	  __property DragWidth ;
	  __property EditDelay ;
	  __property Enabled ;
	  __property Font ;
	  __property Header ;
	  __property HintAnimation ;
	  __property HintMode ;
	  __property HotCursor ;
	  __property Images ;
	  __property Indent ;
	  __property Margin ;
	  //__property NodeDataSize ;
	  __property OLEFormats ;
	  __property Options ;
	  __property ParentBiDiMode ;
	  __property ParentColor ;
	  __property ParentCtl3D ;
	  __property ParentFont ;
	  __property ParentShowHint ;
	  __property PopupMenu ;
	  //__property RootNodeCount ;
	  __property ScrollBarOptions ;
	  __property ShowHint ;
	  __property StateImages ;
	  __property StringOptions ;
	  __property TabOrder ;
	  __property TabStop ;
	  __property TextMargin ;
	  __property Visible ;

	  __property OnAfterCellPaint ;
	  __property OnAfterItemErase ;
	  __property OnAfterItemPaint ;
	  __property OnAfterPaint ;
	  __property OnBeforeCellPaint ;
	  __property OnBeforeItemErase ;
	  __property OnBeforeItemPaint ;
	  __property OnBeforePaint ;
	  __property OnChange ;
	  __property OnChecked ;
	  __property OnChecking ;
	  __property OnClick ;
	  __property OnCollapsed ;
	  __property OnCollapsing ;
	  __property OnColumnClick ;
	  __property OnColumnDblClick ;
	  __property OnColumnResize ;
	  __property OnCompareNodes ;
	  __property OnCreateDragManager ;

	  __property OnCreateEditor ;
	  __property OnDblClick ;
	  __property OnDragAllowed ;
	  //__property OnDragOver ;
	  __property OnDragDrop ;
	  __property OnDrawHeader ;

	  __property OnGetText ;
	  __property OnEditCancelled ;
	  __property OnEdited ;
	  __property OnEditing ;
	  __property OnEndDock ;
	  __property OnEnter ;
	  __property OnExit ;
	  __property OnExpanded ;
	  __property OnExpanding ;
	  __property OnFocusChanged ;
	  __property OnFocusChanging ;
	  __property OnFreeNode ;
	  __property OnPaintText ;
	  __property OnGetHelpContext ;
	  __property OnGetImageIndex ;
	  __property OnGetHint ;
	  //__property OnGetNodeDataSize ;
	  __property OnGetPopupMenu ;
	  __property OnHeaderClick ;
	  __property OnHeaderDblClick ;
	  __property OnHeaderMouseDown ;
	  __property OnHeaderMouseMove ;
	  __property OnHeaderMouseUp ;
	  __property OnHotChange ;
	  //__property OnInitChildren ;
	  __property OnInitNode ;
	  __property OnKeyAction ;
	  __property OnKeyDown ;
	  __property OnKeyPress ;
	  __property OnKeyUp ;
	  __property OnLoadNode ;
	  __property OnMouseDown ;
	  __property OnMouseMove ;
	  __property OnMouseUp ;
	  __property OnNewText ;
	  //__property OnNodeCopied ;
	  //__property OnNodeCopying ;
	  //__property OnNodeMoved ;
	  //__property OnNodeMoving ;
	  __property OnResetNode ;
	  __property OnResize ;
	  __property OnSaveNode ;
	  __property OnStartDock ;
	  __property OnStartDrag ;
	  //__property OnStructureChange ;
};

class PACKAGE TDBCheckVirtualDBTree : public TCustomDBCheckVirtualDBTree
{
  private:
    void        __fastcall SetNodeText(PVirtualNode Node, WideString value);
    WideString  __fastcall GetNodeText(PVirtualNode Node);

  protected:
    virtual void __fastcall DoReadNodeFromDB(PVirtualNode Node);
    virtual void __fastcall DoNodeDataChanged(PVirtualNode Node, TField* Field, bool& UpdateNode);
    virtual void __fastcall DoGetText(PVirtualNode Node, int Column, TVSTTextType TextType, WideString& Text);
	  virtual void __fastcall DoNewText(PVirtualNode Node, int Column, WideString Text);
    virtual void __fastcall DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow);
    virtual int  __fastcall DoCompare(PVirtualNode Node1, PVirtualNode Node2, int Column);

  public:
    __fastcall TDBCheckVirtualDBTree(TComponent* Owner);

    __property WideString NodeText[PVirtualNode Node] = { read=GetNodeText, write=SetNodeText };


  __published:

    __property OnOpeningDataSet;
    __property OnWritingDataSet;
    __property OnReadPathFromDB;
    __property OnWritePathToDB;

    __property DBOptions;

    __property ViewFieldName;
    __property KeyFieldName;
    __property ParentFieldName;
    __property PathFieldName;
    __property LevelFieldName;

    __property DataSource;
    __property CheckDataSource;
    __property ResultFieldName;

    __property Align ;
	  __property Alignment ;
	  __property Anchors ;
	  __property AutoExpandDelay ;
	  __property AutoScrollDelay ;
	  __property AutoScrollInterval ;
	  __property Background ;
	  __property BiDiMode ;
	  __property BevelEdges ;
	  __property BevelInner ;
	  __property BevelOuter ;
	  __property BevelKind ;
	  __property BevelWidth ;
	  __property BorderStyle ;
	  __property ButtonStyle ;
	  __property BorderWidth ;
	  __property ChangeDelay ;
	  __property CheckImageKind ;
	  __property Color ;
	  __property Colors ;
	  __property Ctl3D ;
	  __property Constraints ;
	  __property CustomCheckImages ;
	  __property DefaultNodeHeight ;
	  __property DefaultPasteMode ;
	  __property DefaultText ;
	  __property DragHeight ;
	  __property DragKind ;
	  __property DragImageKind ;
	  __property DragMode ;
	  __property DragOperations ;
	  __property DragType ;
	  __property DragWidth ;
	  __property EditDelay ;
	  __property Enabled ;
	  __property Font ;
	  __property Header ;
	  __property HintAnimation ;
	  __property HintMode ;
	  __property HotCursor ;
	  __property Images ;
	  __property Indent ;
	  __property Margin ;
	  //__property NodeDataSize ;
	  __property OLEFormats ;
	  __property Options ;
	  __property ParentBiDiMode ;
	  __property ParentColor ;
	  __property ParentCtl3D ;
	  __property ParentFont ;
	  __property ParentShowHint ;
	  __property PopupMenu ;
	  //__property RootNodeCount ;
	  __property ScrollBarOptions ;
	  __property ShowHint ;
	  __property StateImages ;
	  __property StringOptions ;
	  __property TabOrder ;
	  __property TabStop ;
	  __property TextMargin ;
	  __property Visible ;

	  __property OnAfterCellPaint ;
	  __property OnAfterItemErase ;
	  __property OnAfterItemPaint ;
	  __property OnAfterPaint ;
	  __property OnBeforeCellPaint ;
	  __property OnBeforeItemErase ;
	  __property OnBeforeItemPaint ;
	  __property OnBeforePaint ;
	  __property OnChange ;
	  __property OnChecked ;
	  __property OnChecking ;
	  __property OnClick ;
	  __property OnCollapsed ;
	  __property OnCollapsing ;
	  __property OnColumnClick ;
	  __property OnColumnDblClick ;
	  __property OnColumnResize ;
	  __property OnCompareNodes ;
	  __property OnCreateDragManager ;

	  __property OnCreateEditor ;
	  __property OnDblClick ;
	  __property OnDragAllowed ;
	  //__property OnDragOver ;
	  __property OnDragDrop ;
	  __property OnDrawHeader ;

	  __property OnGetText ;
	  __property OnEditCancelled ;
	  __property OnEdited ;
	  __property OnEditing ;
	  __property OnEndDock ;
	  __property OnEnter ;
	  __property OnExit ;
	  __property OnExpanded ;
	  __property OnExpanding ;
	  __property OnFocusChanged ;
	  __property OnFocusChanging ;
	  __property OnFreeNode ;
	  __property OnPaintText ;
	  __property OnGetHelpContext ;
	  __property OnGetImageIndex ;
	  __property OnGetHint ;
	  //__property OnGetNodeDataSize ;
	  __property OnGetPopupMenu ;
	  __property OnHeaderClick ;
	  __property OnHeaderDblClick ;
	  __property OnHeaderMouseDown ;
	  __property OnHeaderMouseMove ;
	  __property OnHeaderMouseUp ;
	  __property OnHotChange ;
	  //__property OnInitChildren ;
	  __property OnInitNode ;
	  __property OnKeyAction ;
	  __property OnKeyDown ;
	  __property OnKeyPress ;
	  __property OnKeyUp ;
	  __property OnLoadNode ;
	  __property OnMouseDown ;
	  __property OnMouseMove ;
	  __property OnMouseUp ;
	  __property OnNewText ;
	  //__property OnNodeCopied ;
	  //__property OnNodeCopying ;
	  //__property OnNodeMoved ;
	  //__property OnNodeMoving ;
	  __property OnResetNode ;
	  __property OnResize ;
	  __property OnSaveNode ;
	  __property OnStartDock ;
	  __property OnStartDrag ;
	  //__property OnStructureChange ;
};

//==============================================================================
class PACKAGE TCheckVirtualDBTree : public TCustomCheckVirtualDBTree
{
  private:
    void        __fastcall SetNodeText(PVirtualNode Node, WideString value);
    WideString  __fastcall GetNodeText(PVirtualNode Node);

  protected:
    virtual void __fastcall DoReadNodeFromDB(PVirtualNode Node);
    virtual void __fastcall DoNodeDataChanged(PVirtualNode Node, TField* Field, bool& UpdateNode);
    virtual void __fastcall DoGetText(PVirtualNode Node, int Column, TVSTTextType TextType, WideString& Text);
	  virtual void __fastcall DoNewText(PVirtualNode Node, int Column, WideString Text);
    virtual void __fastcall DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow);
    virtual int  __fastcall DoCompare(PVirtualNode Node1, PVirtualNode Node2, int Column);

  public:
    __fastcall TCheckVirtualDBTree(TComponent* Owner);

    __property WideString NodeText[PVirtualNode Node] = { read=GetNodeText, write=SetNodeText };


  __published:

    __property OnOpeningDataSet;
    __property OnWritingDataSet;
    __property OnReadPathFromDB;
    __property OnWritePathToDB;

    __property ViewFieldName;
    __property KeyFieldName;
    __property ParentFieldName;
    __property PathFieldName;
    __property LevelFieldName;
    __property DataSource;

    __property DBOptions;

    __property Align ;
	  __property Alignment ;
	  __property Anchors ;
	  __property AutoExpandDelay ;
	  __property AutoScrollDelay ;
	  __property AutoScrollInterval ;
	  __property Background ;
	  __property BiDiMode ;
	  __property BevelEdges ;
	  __property BevelInner ;
	  __property BevelOuter ;
	  __property BevelKind ;
	  __property BevelWidth ;
	  __property BorderStyle ;
	  __property ButtonStyle ;
	  __property BorderWidth ;
	  __property ChangeDelay ;
	  __property CheckImageKind ;
	  __property Color ;
	  __property Colors ;
	  __property Ctl3D ;
	  __property Constraints ;
	  __property CustomCheckImages ;
	  __property DefaultNodeHeight ;
	  __property DefaultPasteMode ;
	  __property DefaultText ;
	  __property DragHeight ;
	  __property DragKind ;
	  __property DragImageKind ;
	  __property DragMode ;
	  __property DragOperations ;
	  __property DragType ;
	  __property DragWidth ;
	  __property EditDelay ;
	  __property Enabled ;
	  __property Font ;
	  __property Header ;
	  __property HintAnimation ;
	  __property HintMode ;
	  __property HotCursor ;
	  __property Images ;
	  __property Indent ;
	  __property Margin ;
	  //__property NodeDataSize ;
	  __property OLEFormats ;
	  __property Options ;
	  __property ParentBiDiMode ;
	  __property ParentColor ;
	  __property ParentCtl3D ;
	  __property ParentFont ;
	  __property ParentShowHint ;
	  __property PopupMenu ;
	  //__property RootNodeCount ;
	  __property ScrollBarOptions ;
	  __property ShowHint ;
	  __property StateImages ;
	  __property StringOptions ;
	  __property TabOrder ;
	  __property TabStop ;
	  __property TextMargin ;
	  __property Visible ;

	  __property OnAfterCellPaint ;
	  __property OnAfterItemErase ;
	  __property OnAfterItemPaint ;
	  __property OnAfterPaint ;
	  __property OnBeforeCellPaint ;
	  __property OnBeforeItemErase ;
	  __property OnBeforeItemPaint ;
	  __property OnBeforePaint ;
	  __property OnChange ;
	  __property OnChecked ;
	  __property OnChecking ;
	  __property OnClick ;
	  __property OnCollapsed ;
	  __property OnCollapsing ;
	  __property OnColumnClick ;
	  __property OnColumnDblClick ;
	  __property OnColumnResize ;
	  __property OnCompareNodes ;
	  __property OnCreateDragManager ;

	  __property OnCreateEditor ;
	  __property OnDblClick ;
	  __property OnDragAllowed ;
	  //__property OnDragOver ;
	  __property OnDragDrop ;
	  __property OnDrawHeader ;

	  __property OnGetText ;
	  __property OnEditCancelled ;
	  __property OnEdited ;
	  __property OnEditing ;
	  __property OnEndDock ;
	  __property OnEnter ;
	  __property OnExit ;
	  __property OnExpanded ;
	  __property OnExpanding ;
	  __property OnFocusChanged ;
	  __property OnFocusChanging ;
	  __property OnFreeNode ;
	  __property OnPaintText ;
	  __property OnGetHelpContext ;
	  __property OnGetImageIndex ;
	  __property OnGetHint ;
	  //__property OnGetNodeDataSize ;
	  __property OnGetPopupMenu ;
	  __property OnHeaderClick ;
	  __property OnHeaderDblClick ;
	  __property OnHeaderMouseDown ;
	  __property OnHeaderMouseMove ;
	  __property OnHeaderMouseUp ;
	  __property OnHotChange ;
	  //__property OnInitChildren ;
	  __property OnInitNode ;
	  __property OnKeyAction ;
	  __property OnKeyDown ;
	  __property OnKeyPress ;
	  __property OnKeyUp ;
	  __property OnLoadNode ;
	  __property OnMouseDown ;
	  __property OnMouseMove ;
	  __property OnMouseUp ;
	  __property OnNewText ;
	  //__property OnNodeCopied ;
	  //__property OnNodeCopying ;
	  //__property OnNodeMoved ;
	  //__property OnNodeMoving ;
	  __property OnResetNode ;
	  __property OnResize ;
	  __property OnSaveNode ;
	  __property OnStartDock ;
	  __property OnStartDrag ;
	  //__property OnStructureChange ;
};

#endif
