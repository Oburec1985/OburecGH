Demos for DBVT package
To run it you must have installed Delphi/BCB Professional or Enterprise.
Create Alias for included Database. Alias name - VerbumDB, type - Paradox.

 Start with Test1.exe