//---------------------------------------------------------------------------

#include <vcl.h>
#include <SysUtils.hpp>
#include <Controls.hpp>
#include <Classes.hpp>
#include <Forms.hpp>
#include <DB.hpp>

#include "VirtualTrees.hpp"

#pragma hdrstop

#include "BaseVirtualDBTree.h"
#include "CustomSimpleVirtualDBTree.h"

#pragma package(smart_init)
//------------------------------------------------------------------------------
// ValidCtrCheck is used to assure that the components created do not have
// any pure virtual functions.
//

static inline void ValidCtrCheck(TCustomSimpleVirtualDBTree *)
{
  new TCustomSimpleVirtualDBTree(NULL);
}
//------------------------------------------------------------------------------

namespace Customsimplevirtualdbtree
{
  void __fastcall PACKAGE Register()
  {
     TComponentClass classes[3] = { __classid(TSimpleVirtualDBTree),
                                    __classid(TDBCheckVirtualDBTree),
                                    __classid(TCheckVirtualDBTree)};
     RegisterComponents("Virtual Controls", classes, 2);
  }
}

//==============================================================================
// ����� TCustomSimpleVirtualDBTree
//

//------------------------------------------------------------------------------
// �����������
//
__fastcall TCustomSimpleVirtualDBTree::TCustomSimpleVirtualDBTree(TComponent* Owner)
  : TBaseVirtualDBTree(Owner)
{
  // ������������� ���� � �������
  FViewField = 0;
}

//------------------------------------------------------------------------------
// ��������� ���� � �������
//
void __fastcall TCustomSimpleVirtualDBTree::SetViewFieldName(AnsiString value)
{
  if(FViewFieldName != value)
  {
    FViewField = 0;
    FViewFieldName = value;
    // ���������� ������
    DataLinkActiveChanged();
  }
}

//------------------------------------------------------------------------------
// ������� �����
//
void __fastcall TCustomSimpleVirtualDBTree::ResetFields()
{
  TBaseVirtualDBTree::ResetFields();
  FViewField = 0;
}

//------------------------------------------------------------------------------
// ������������� �����
//
void __fastcall TCustomSimpleVirtualDBTree::InitFields()
{
  TBaseVirtualDBTree::InitFields();
  if(FViewFieldName != "")
    FViewField = DataSource->DataSet->FieldByName(FViewFieldName);
}

//------------------------------------------------------------------------------
// ������ �� �������� �� - ����� ���������, ���� ���� � ������� ����������
//
void __fastcall TCustomSimpleVirtualDBTree::DoOpeningDataSet(bool& Allow)
{
  Allow = (FViewField != 0);
  if(Allow)
    TBaseVirtualDBTree::DoOpeningDataSet(Allow);
}

//------------------------------------------------------------------------------
// ������ �� ������ � �� - ���� ����� � ���� � �������, �� ��� ������ ��������� ������
//
void __fastcall TCustomSimpleVirtualDBTree::DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow)
{
  if(ChangeMode == dbcmEdit && Column == Header->MainColumn)
    Allow =  FViewField->CanModify;
  if(Allow)
    TBaseVirtualDBTree::DoWritingDataSet(Node, Column, ChangeMode, Allow);
}


//==============================================================================
// ����� TSimpleVirtualDBTree
//
__fastcall TSimpleVirtualDBTree::TSimpleVirtualDBTree(TComponent* Owner)
 : TCustomSimpleVirtualDBTree(Owner)
{
  DBNodeDataSize = sizeof(TSimpleData);
}

//------------------------------------------------------------------------------
// ���������� ������ �� ��
//
void __fastcall TSimpleVirtualDBTree::DoReadNodeFromDB(PVirtualNode Node)
{
  NodeText[Node] = ViewField->AsString;
}

//------------------------------------------------------------------------------
// ���� � ������� ����������
//
void __fastcall TSimpleVirtualDBTree::DoNodeDataChanged(PVirtualNode Node, TField* Field, bool& UpdateNode)
{
  if(Field == ViewField)
  {
    NodeText[Node] = Field->AsString;
    UpdateNode     = true;
  }
}

//------------------------------------------------------------------------------
// ����� ������� �������
//
void __fastcall TSimpleVirtualDBTree::DoGetText(PVirtualNode Node, int Column, TVSTTextType TextType, WideString& Text)
{
  if(Node && Node != RootNode)
  {
    if(Column == Header->MainColumn && TextType == ttNormal)
    {
      Text = NodeText[Node];
    }
    else
    {
      TCustomSimpleVirtualDBTree::DoGetText(Node, Column, TextType, Text);
    }
  }
}

//------------------------------------------------------------------------------
// ����� ����� �����
//
void __fastcall TSimpleVirtualDBTree::DoNewText(PVirtualNode Node, int Column, WideString Text)
{
  if(Column == Header->MainColumn)
  {
    ViewField->AsString = Text;
  }
}

//------------------------------------------------------------------------------
// ������ �� ������ - ����� ���������� ������ � ������� �������
//
void __fastcall TSimpleVirtualDBTree::DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow)
{
  if(ChangeMode == dbcmEdit)
  {
    if(Column == Header->MainColumn)
      TCustomSimpleVirtualDBTree::DoWritingDataSet(Node, Column, ChangeMode, Allow);
    else
      Allow = false;
  }
}

//------------------------------------------------------------------------------
// ��������� ��������� ���� �����
//
int  __fastcall TSimpleVirtualDBTree::DoCompare(PVirtualNode Node1, PVirtualNode Node2, int Column)
{
  if(Column == Header->MainColumn)
   return (NodeText[Node1] > NodeText[Node2]) ? 1 : -1;
  return 0;
}

//------------------------------------------------------------------------------
void __fastcall TSimpleVirtualDBTree::SetNodeText(PVirtualNode Node, WideString value)
{
  if(Node)
  {
    TSimpleData* Data = (TSimpleData* )GetDBNodeData(Node);
    Data->Text        = value;
  }
}

//------------------------------------------------------------------------------
WideString __fastcall TSimpleVirtualDBTree::GetNodeText(PVirtualNode Node)
{
  WideString Result;
  if(Node)
  {
    TSimpleData* Data = (TSimpleData* )GetDBNodeData(Node);
    Result            = Data->Text;
  }
  return Result;
}

//==============================================================================
__fastcall TCustomDBCheckVirtualDBTree::TCustomDBCheckVirtualDBTree(TComponent* Owner)
 : TCustomSimpleVirtualDBTree(Owner)
{
  FCheckDataLink = new TCheckDataLink(this);

  DBOptions = DBOptions >> dboTrackChanges;
  DBOptions = DBOptions << dboShowChecks << dboAllowChecking;

  FResultField = 0;
}

__fastcall TCustomDBCheckVirtualDBTree::~TCustomDBCheckVirtualDBTree()
{
  delete FCheckDataLink;
}
//==============================================================================
__fastcall TCheckDataLink::TCheckDataLink(TCustomDBCheckVirtualDBTree* ATree)
: TDataLink()
{
  FTree = ATree;
}

void __fastcall TCheckDataLink::ActiveChanged()
{
  FTree->CheckDataLinkActiveChanged();
}

void __fastcall TCustomDBCheckVirtualDBTree::CheckDataLinkActiveChanged()
{
  if(!ComponentState.Contains(csDesigning))
  {
    FResultField = 0;
    if(FCheckDataLink->Active)
    {
      if(FResultFieldName != "")
        FResultField = FCheckDataLink->DataSet->FieldByName(FResultFieldName);
    }

    Update();
  }
}

void __fastcall TCustomDBCheckVirtualDBTree::DoOpeningDataSet(bool& Allow)
{
  if(FResultField)
    TCustomSimpleVirtualDBTree::DoOpeningDataSet(Allow);
  else
   Allow = false;
}

void __fastcall TCustomDBCheckVirtualDBTree::SetCheckDataSource(TDataSource* value)
{
  FCheckDataLink->DataSource = value;
  if(value)
    value->FreeNotification(this);
}

TDataSource* __fastcall TCustomDBCheckVirtualDBTree::GetCheckDataSource()
{
  return FCheckDataLink->DataSource;
}

void __fastcall TCustomDBCheckVirtualDBTree::Notification(TComponent* AComponent, TOperation Operation)
{
  TCustomSimpleVirtualDBTree::Notification(AComponent, Operation);
  if(Operation == opRemove && FCheckDataLink && AComponent == CheckDataSource)
    CheckDataSource = 0;
}

void __fastcall TCustomDBCheckVirtualDBTree::SetResultFieldName(AnsiString value)
{
  if(FResultFieldName != value)
  {
    FResultFieldName = value;
    CheckDataLinkActiveChanged();
  }
}

bool __fastcall TCustomDBCheckVirtualDBTree::DoChecking(PVirtualNode Node, TCheckState NewCheckState)
{
  if(DBStatus.Contains(dbtsDataChanging))
    return TCustomSimpleVirtualDBTree::DoChecking(Node, NewCheckState);

  if(FResultField && FResultField->CanModify)
    return TCustomSimpleVirtualDBTree::DoChecking(Node, NewCheckState);
  return false;
}

void __fastcall TCustomDBCheckVirtualDBTree::DoChecked(PVirtualNode Node)
{
  if(!DBStatus.Contains(dbtsDataChanging))
  {
    TDBVTData* Data = (TDBVTData* )GetNodeData(Node);
    if(CheckState[Node] == csChecked)
    {
      FCheckDataLink->DataSet->Insert();
      FResultField->AsInteger = Data->ID;
      FCheckDataLink->DataSet->Post();
    }
    else
    {
      if(FCheckDataLink->DataSet->Locate(FResultFieldName, Data->ID, TLocateOptions()))
        FCheckDataLink->DataSet->Delete();
    }
  }
  TCustomSimpleVirtualDBTree::DoChecked(Node);
}

void __fastcall TCustomDBCheckVirtualDBTree::DoReadNodeFromDB(PVirtualNode Node)
{
  TCustomSimpleVirtualDBTree::DoReadNodeFromDB(Node);

  TDBVTData* Data = (TDBVTData* )GetNodeData(Node);
  if(FCheckDataLink->DataSet->Locate(FResultFieldName, Data->ID, TLocateOptions()))
  {
    CheckState[Node] = csChecked;
  }
  else
  {
    CheckState[Node] = csUnchecked;
  }
}

//==============================================================================
//==============================================================================
// ����� TDBCheckVirtualDBTree
//
__fastcall TDBCheckVirtualDBTree::TDBCheckVirtualDBTree(TComponent* Owner)
 : TCustomDBCheckVirtualDBTree(Owner)
{
  DBNodeDataSize = sizeof(TSimpleData);
}

//------------------------------------------------------------------------------
// ���������� ������ �� ��
//
void __fastcall TDBCheckVirtualDBTree::DoReadNodeFromDB(PVirtualNode Node)
{
  NodeText[Node] = ViewField->AsString;
  TCustomDBCheckVirtualDBTree::DoReadNodeFromDB(Node);
}

//------------------------------------------------------------------------------
// ���� � ������� ����������
//
void __fastcall TDBCheckVirtualDBTree::DoNodeDataChanged(PVirtualNode Node, TField* Field, bool& UpdateNode)
{
  if(Field == ViewField)
  {
    NodeText[Node] = Field->AsString;
    UpdateNode     = true;
  }
}

//------------------------------------------------------------------------------
// ����� ������� �������
//
void __fastcall TDBCheckVirtualDBTree::DoGetText(PVirtualNode Node, int Column, TVSTTextType TextType, WideString& Text)
{
  if(Node && Node != RootNode)
  {
    if(Column == Header->MainColumn && TextType == ttNormal)
    {
      Text = NodeText[Node];
    }
    else
    {
      TCustomDBCheckVirtualDBTree::DoGetText(Node, Column, TextType, Text);
    }
  }
}

//------------------------------------------------------------------------------
// ����� ����� �����
//
void __fastcall TDBCheckVirtualDBTree::DoNewText(PVirtualNode Node, int Column, WideString Text)
{
  if(Column == Header->MainColumn)
  {
    ViewField->AsString = Text;
  }
}

//------------------------------------------------------------------------------
// ������ �� ������ - ����� ���������� ������ � ������� �������
//
void __fastcall TDBCheckVirtualDBTree::DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow)
{
  if(ChangeMode == dbcmEdit)
  {
    if(Column == Header->MainColumn)
      TCustomDBCheckVirtualDBTree::DoWritingDataSet(Node, Column, ChangeMode, Allow);
    else
      Allow = false;
  }
}

//------------------------------------------------------------------------------
// ��������� ��������� ���� �����
//
int  __fastcall TDBCheckVirtualDBTree::DoCompare(PVirtualNode Node1, PVirtualNode Node2, int Column)
{
  if(Column == Header->MainColumn)
   return (NodeText[Node1] > NodeText[Node2]) ? 1 : -1;
  return 0;
}

//------------------------------------------------------------------------------
void __fastcall TDBCheckVirtualDBTree::SetNodeText(PVirtualNode Node, WideString value)
{
  if(Node)
  {
    TSimpleData* Data = (TSimpleData* )GetDBNodeData(Node);
    Data->Text        = value;
  }
}

//------------------------------------------------------------------------------
WideString __fastcall TDBCheckVirtualDBTree::GetNodeText(PVirtualNode Node)
{
  WideString Result;
  if(Node)
  {
    TSimpleData* Data = (TSimpleData* )GetDBNodeData(Node);
    Result            = Data->Text;
  }
  return Result;
}
//==============================================================================
__fastcall TCustomCheckVirtualDBTree::TCustomCheckVirtualDBTree(TComponent* Owner)
 : TCustomSimpleVirtualDBTree(Owner)
{
  FList = new TStringList();
  FList->Sorted = true;

  DBOptions = DBOptions >> dboTrackChanges;
  DBOptions = DBOptions << dboShowChecks << dboAllowChecking;
}

__fastcall TCustomCheckVirtualDBTree::~TCustomCheckVirtualDBTree()
{
  delete FList;
}
//==============================================================================

TStringList* __fastcall TCustomCheckVirtualDBTree::GetCheckList()
{
  TStringList* Result = new TStringList();
  Result->Assign(FList);
  return Result;
}

void __fastcall TCustomCheckVirtualDBTree::SetCheckList(TStringList* value)
{
  FList->Assign(value);
  Update();
}


void __fastcall TCustomCheckVirtualDBTree::DoChecked(PVirtualNode Node)
{
  if(!DBStatus.Contains(dbtsDataChanging))
  {
    TDBVTData* Data = (TDBVTData* )GetNodeData(Node);
    if(CheckState[Node] == csChecked)
    {
      FList->Add(AnsiString(Data->ID));
    }
    else
    {
      int Index = FList->IndexOf(AnsiString(Data->ID));
      if(Index != -1)
      {
        FList->Delete(Index);
      }
    }
  }
  TCustomSimpleVirtualDBTree::DoChecked(Node);
}

void __fastcall TCustomCheckVirtualDBTree::DoReadNodeFromDB(PVirtualNode Node)
{
  TCustomSimpleVirtualDBTree::DoReadNodeFromDB(Node);

  int Index;
  TDBVTData* Data = (TDBVTData* )GetNodeData(Node);

  if(FList->Find(AnsiString(Data->ID), Index))
  {
    CheckState[Node] = csChecked;
  }
  else
  {
    CheckState[Node] = csUnchecked;
  }
}

//==============================================================================
//
__fastcall TCheckVirtualDBTree::TCheckVirtualDBTree(TComponent* Owner)
 : TCustomCheckVirtualDBTree(Owner)
{
  DBNodeDataSize = sizeof(TSimpleData);
}

//------------------------------------------------------------------------------
// ���������� ������ �� ��
//
void __fastcall TCheckVirtualDBTree::DoReadNodeFromDB(PVirtualNode Node)
{
  NodeText[Node] = ViewField->AsString;
  TCustomCheckVirtualDBTree::DoReadNodeFromDB(Node);
}

//------------------------------------------------------------------------------
// ���� � ������� ����������
//
void __fastcall TCheckVirtualDBTree::DoNodeDataChanged(PVirtualNode Node, TField* Field, bool& UpdateNode)
{
  if(Field == ViewField)
  {
    NodeText[Node] = Field->AsString;
    UpdateNode     = true;
  }
}

//------------------------------------------------------------------------------
// ����� ������� �������
//
void __fastcall TCheckVirtualDBTree::DoGetText(PVirtualNode Node, int Column, TVSTTextType TextType, WideString& Text)
{
  if(Node && Node != RootNode)
  {
    if(Column == Header->MainColumn && TextType == ttNormal)
    {
      Text = NodeText[Node];
    }
    else
    {
      TCustomCheckVirtualDBTree::DoGetText(Node, Column, TextType, Text);
    }
  }
}

//------------------------------------------------------------------------------
// ����� ����� �����
//
void __fastcall TCheckVirtualDBTree::DoNewText(PVirtualNode Node, int Column, WideString Text)
{
  if(Column == Header->MainColumn)
  {
    ViewField->AsString = Text;
  }
}

//------------------------------------------------------------------------------
// ������ �� ������ - ����� ���������� ������ � ������� �������
//
void __fastcall TCheckVirtualDBTree::DoWritingDataSet(PVirtualNode Node, int Column, TDBVTChangeMode ChangeMode, bool& Allow)
{
  if(ChangeMode == dbcmEdit)
  {
    if(Column == Header->MainColumn)
      TCustomCheckVirtualDBTree::DoWritingDataSet(Node, Column, ChangeMode, Allow);
    else
      Allow = false;
  }
}

//------------------------------------------------------------------------------
// ��������� ��������� ���� �����
//
int  __fastcall TCheckVirtualDBTree::DoCompare(PVirtualNode Node1, PVirtualNode Node2, int Column)
{
  if(Column == Header->MainColumn)
   return (NodeText[Node1] > NodeText[Node2]) ? 1 : -1;
  return 0;
}

//------------------------------------------------------------------------------
void __fastcall TCheckVirtualDBTree::SetNodeText(PVirtualNode Node, WideString value)
{
  if(Node)
  {
    TSimpleData* Data = (TSimpleData* )GetDBNodeData(Node);
    Data->Text        = value;
  }
}

//------------------------------------------------------------------------------
WideString __fastcall TCheckVirtualDBTree::GetNodeText(PVirtualNode Node)
{
  WideString Result("");
  if(Node && Node != RootNode)
  {
    TSimpleData* Data = (TSimpleData* )GetDBNodeData(Node);
    Result            = Data->Text;
  }
  return Result;
}

TStringList* __fastcall TCustomDBCheckVirtualDBTree::GetCheckList()
{
  TStringList* Result = new TStringList();

  TDBVTData* Data;
  PVirtualNode Node = GetFirst();
  while(Node)
  {
    Data = (TDBVTData* )GetNodeData(Node);
    if(CheckState[Node] == csChecked)
      Result->Add(AnsiString(Data->ID));
    Node = GetNext(Node);
  }

  return Result;
}

