GeomFit3D application
---------------------

Maintained by Nils Haeck M.Sc.

Compiling with Delphi7
======================
Besides the source units of this project, you need to download and install GlScene.