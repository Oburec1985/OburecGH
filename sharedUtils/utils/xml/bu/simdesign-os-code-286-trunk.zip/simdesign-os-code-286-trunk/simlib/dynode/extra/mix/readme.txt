Classes.pas: delphi7
Variants.pas: lvcl
