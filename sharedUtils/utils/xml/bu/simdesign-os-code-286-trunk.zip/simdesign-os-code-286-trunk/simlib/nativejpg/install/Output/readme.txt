Source distribution
===================
- Run nativejpg_source.iss
- Add resulting NativeJpg.exe to a zipfile called NativeXml.zip and use password "simjpglib". 
- Put in C:\Server\Sim\Download\Registered

ZIP file with installer:
http://www.simdesign.nl/download/registered/nativejpg.zip
Password: simjpglib

Trial EXE distribution
======================
- Run CompileAll.bat in \Packages folder.
- Run nativejpg_trial.iss
- Put resulting InstallNativeJpg(trial).exe in C:\Server\Sim\Download


