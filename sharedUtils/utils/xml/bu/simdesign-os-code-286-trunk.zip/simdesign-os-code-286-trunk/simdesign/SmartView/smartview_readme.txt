SmartView paradigm

SmartView aims to use two special (virtual) trees to browse files files in the HD folders.

The first treeview comprises of a list of files being browsed. It is just a view not a tree.

The second is also just a view, text based, to click towards a category (swipe right). Categories, "to read", "to file". etc, but also user defined categories can be defined as well, see "lists". 