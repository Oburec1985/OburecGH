--print(package.path)

--[[
require'lfs'

print(lfs.currentdir ())

--table.foreach(_G, print)
]]

for i= 0,9 do
  print(i)
end