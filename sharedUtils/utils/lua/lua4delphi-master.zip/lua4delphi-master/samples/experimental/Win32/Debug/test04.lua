a = {
	nome = "Daniele",
	cognome = "Teti",
	eta = 32
	}

for k,v in pairs(a) do
  print(k..'='..v)
end
