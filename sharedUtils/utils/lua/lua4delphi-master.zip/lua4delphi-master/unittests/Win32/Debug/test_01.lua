local x = 1+2+3;
local s = "Hello World";
if (x > 2) then
  print(s);
end
