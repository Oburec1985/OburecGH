io.write [[
Ciao
]] io.write("hello") 
io.write [[

mondo
]] io.write("world") 
io.write [[

close]]