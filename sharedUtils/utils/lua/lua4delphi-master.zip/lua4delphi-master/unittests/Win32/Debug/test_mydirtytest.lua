local sl = TStringList.new()
sl:add('Hello World')
--sl.add('Hello World2')


