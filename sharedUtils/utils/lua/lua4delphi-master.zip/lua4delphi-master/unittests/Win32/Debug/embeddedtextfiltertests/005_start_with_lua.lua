 local x = 1 
io.write [[

Hello World ]]io.write( x)
io.write [[
]]