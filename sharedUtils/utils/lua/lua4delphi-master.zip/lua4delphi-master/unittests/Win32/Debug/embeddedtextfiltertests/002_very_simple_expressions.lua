io.write [[
Ciao
]] io.write("hello") 
io.write [[

mondo
]] io.write("world") 
io.write [[

Hi, my name is ]]io.write( "Daniele Teti" )
io.write [[
. What's your name?
close]]