# lua4delphi
Delphi binding for Lua 5.1 language

This project was initially part of [DelphiMVCFramework](https://github.com/danieleteti/delphimvcframework) but now it is an indipendent project.
