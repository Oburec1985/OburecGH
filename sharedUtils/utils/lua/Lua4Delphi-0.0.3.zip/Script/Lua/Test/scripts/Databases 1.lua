-- Test of Databases Accessing 

F = GetObject('Form1');
X = CreateObject('TTable', true, F);
X.
X.Parent = F.Panel1;
X.Left = 20;
X.Top = 30;

