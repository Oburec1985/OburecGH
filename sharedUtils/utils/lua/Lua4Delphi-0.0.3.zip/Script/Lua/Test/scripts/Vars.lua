F = CreateObject("TMyTest", true);
X = 3;
fRes, X = F:TestA(false, nil, X, "TEst");

