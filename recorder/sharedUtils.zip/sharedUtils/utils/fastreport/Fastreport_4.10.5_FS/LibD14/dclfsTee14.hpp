// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dclfstee14.pas' rev: 21.00

#ifndef Dclfstee14HPP
#define Dclfstee14HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Fs_iteereg.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Ioutils.hpp>	// Pascal unit
#include <Inifiles.hpp>	// Pascal unit
#include <Multimon.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Actnlist.hpp>	// Pascal unit
#include <Helpintfs.hpp>	// Pascal unit
#include <Timespan.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Uxtheme.hpp>	// Pascal unit
#include <Flatsb.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <Themes.hpp>	// Pascal unit
#include <Graphutil.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Clipbrd.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Ansistrings.hpp>	// Pascal unit
#include <Fs_iconst.hpp>	// Pascal unit
#include <Fs_itools.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Fs_iinterpreter.hpp>	// Pascal unit
#include <Fs_iclassesrtti.hpp>	// Pascal unit
#include <Fs_igraphicsrtti.hpp>	// Pascal unit
#include <Fs_iformsrtti.hpp>	// Pascal unit
#include <Teehtml.hpp>	// Pascal unit
#include <Teeconst.hpp>	// Pascal unit
#include <Tecanvas.hpp>	// Pascal unit
#include <Teefilters.hpp>	// Pascal unit
#include <Teeprocs.hpp>	// Pascal unit
#include <Teengine.hpp>	// Pascal unit
#include <Chart.hpp>	// Pascal unit
#include <Fs_ichartrtti.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dclfstee14
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dclfstee14 */
using namespace Dclfstee14;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Dclfstee14HPP
