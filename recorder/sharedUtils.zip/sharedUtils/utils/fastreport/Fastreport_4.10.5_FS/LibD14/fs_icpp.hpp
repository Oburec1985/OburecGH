// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Fs_icpp.pas' rev: 21.00

#ifndef Fs_icppHPP
#define Fs_icppHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Fs_itools.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Fs_icpp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TfsCPP;
class PASCALIMPLEMENTATION TfsCPP : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
public:
	/* TComponent.Create */ inline __fastcall virtual TfsCPP(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	/* TComponent.Destroy */ inline __fastcall virtual ~TfsCPP(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Fs_icpp */
using namespace Fs_icpp;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fs_icppHPP
