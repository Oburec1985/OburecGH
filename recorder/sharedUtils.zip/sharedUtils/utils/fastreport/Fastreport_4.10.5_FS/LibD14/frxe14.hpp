// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Frxe14.pas' rev: 21.00

#ifndef Frxe14HPP
#define Frxe14HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Frxexporthtml.hpp>	// Pascal unit
#include <Frxexportimage.hpp>	// Pascal unit
#include <Frxexportmatrix.hpp>	// Pascal unit
#include <Frxexportpdf.hpp>	// Pascal unit
#include <Frxexportrtf.hpp>	// Pascal unit
#include <Frxexportxls.hpp>	// Pascal unit
#include <Frxexportxml.hpp>	// Pascal unit
#include <Frxexportcsv.hpp>	// Pascal unit
#include <Frxexporttext.hpp>	// Pascal unit
#include <Frxexportmail.hpp>	// Pascal unit
#include <Frxexportodf.hpp>	// Pascal unit
#include <Frxexportdbf.hpp>	// Pascal unit
#include <Frxzip.hpp>	// Pascal unit
#include <Frxfileutils.hpp>	// Pascal unit
#include <Frxnetutils.hpp>	// Pascal unit
#include <Frxsmtp.hpp>	// Pascal unit
#include <Frxrc4.hpp>	// Pascal unit
#include <Frxgml.hpp>	// Pascal unit
#include <Frxrcexports.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Ioutils.hpp>	// Pascal unit
#include <Inifiles.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Multimon.hpp>	// Pascal unit
#include <Actnlist.hpp>	// Pascal unit
#include <Helpintfs.hpp>	// Pascal unit
#include <Timespan.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Uxtheme.hpp>	// Pascal unit
#include <Flatsb.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <Themes.hpp>	// Pascal unit
#include <Graphutil.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Clipbrd.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Widestrings.hpp>	// Pascal unit
#include <Frxchm.hpp>	// Pascal unit
#include <Fs_iconst.hpp>	// Pascal unit
#include <Frxres.hpp>	// Pascal unit
#include <Ansistrings.hpp>	// Pascal unit
#include <Fs_itools.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Fs_iinterpreter.hpp>	// Pascal unit
#include <Frxdsgnintf.hpp>	// Pascal unit
#include <Frxdmpclass.hpp>	// Pascal unit
#include <Frxprinter.hpp>	// Pascal unit
#include <Frxsearchdialog.hpp>	// Pascal unit
#include <Frxpreview.hpp>	// Pascal unit
#include <Frxgraphicutils.hpp>	// Pascal unit
#include <Frxrcclass.hpp>	// Pascal unit
#include <Fs_iclassesrtti.hpp>	// Pascal unit
#include <Fs_igraphicsrtti.hpp>	// Pascal unit
#include <Fs_iformsrtti.hpp>	// Pascal unit
#include <Jpeg.hpp>	// Pascal unit
#include <Pngimage.hpp>	// Pascal unit
#include <Frxclassrtti.hpp>	// Pascal unit
#include <Fs_ipascal.hpp>	// Pascal unit
#include <Fs_icpp.hpp>	// Pascal unit
#include <Fs_ibasic.hpp>	// Pascal unit
#include <Fs_ijs.hpp>	// Pascal unit
#include <Fs_idialogsrtti.hpp>	// Pascal unit
#include <Fs_iinirtti.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Frxe14
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Frxe14 */
using namespace Frxe14;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Frxe14HPP
