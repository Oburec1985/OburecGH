// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dclfrxdb14.pas' rev: 21.00

#ifndef Dclfrxdb14HPP
#define Dclfrxdb14HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Frxregdb.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Ioutils.hpp>	// Pascal unit
#include <Inifiles.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Timespan.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Uxtheme.hpp>	// Pascal unit
#include <Multimon.hpp>	// Pascal unit
#include <Actnlist.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Themes.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Helpintfs.hpp>	// Pascal unit
#include <Flatsb.hpp>	// Pascal unit
#include <Printers.hpp>	// Pascal unit
#include <Graphutil.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Clipbrd.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Idemessages.hpp>	// Pascal unit
#include <Captioneddocktree.hpp>	// Pascal unit
#include <Tabs.hpp>	// Pascal unit
#include <Docktabset.hpp>	// Pascal unit
#include <Percentagedocktree.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Extdlgs.hpp>	// Pascal unit
#include <Mapi.hpp>	// Pascal unit
#include <Extactns.hpp>	// Pascal unit
#include <Actnmenus.hpp>	// Pascal unit
#include <Actnman.hpp>	// Pascal unit
#include <Platformdefaultstyleactnctrls.hpp>	// Pascal unit
#include <Tabdock.hpp>	// Pascal unit
#include <Basedock.hpp>	// Pascal unit
#include <Deskutil.hpp>	// Pascal unit
#include <Deskform.hpp>	// Pascal unit
#include <Dockform.hpp>	// Pascal unit
#include <Msxmldom.hpp>	// Pascal unit
#include <Xmldom.hpp>	// Pascal unit
#include <Xmlintf.hpp>	// Pascal unit
#include <Toolsapi.hpp>	// Pascal unit
#include <Proxies.hpp>	// Pascal unit
#include <Designeditors.hpp>	// Pascal unit
#include <Widestrings.hpp>	// Pascal unit
#include <Frxchm.hpp>	// Pascal unit
#include <Fs_iconst.hpp>	// Pascal unit
#include <Frxres.hpp>	// Pascal unit
#include <Ansistrings.hpp>	// Pascal unit
#include <Fs_itools.hpp>	// Pascal unit
#include <Fs_iinterpreter.hpp>	// Pascal unit
#include <Frxdsgnintf.hpp>	// Pascal unit
#include <Frxdmpclass.hpp>	// Pascal unit
#include <Frxprinter.hpp>	// Pascal unit
#include <Frxsearchdialog.hpp>	// Pascal unit
#include <Frxpreview.hpp>	// Pascal unit
#include <Frxgraphicutils.hpp>	// Pascal unit
#include <Frxrcclass.hpp>	// Pascal unit
#include <Fs_iclassesrtti.hpp>	// Pascal unit
#include <Fs_igraphicsrtti.hpp>	// Pascal unit
#include <Fs_iformsrtti.hpp>	// Pascal unit
#include <Jpeg.hpp>	// Pascal unit
#include <Pngimage.hpp>	// Pascal unit
#include <Frxclassrtti.hpp>	// Pascal unit
#include <Fs_ipascal.hpp>	// Pascal unit
#include <Fs_icpp.hpp>	// Pascal unit
#include <Fs_ibasic.hpp>	// Pascal unit
#include <Fs_ijs.hpp>	// Pascal unit
#include <Fs_idialogsrtti.hpp>	// Pascal unit
#include <Fs_iinirtti.hpp>	// Pascal unit
#include <Frxclass.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Fmtbcd.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dblogdlg.hpp>	// Pascal unit
#include <Dbpwdlg.hpp>	// Pascal unit
#include <Dbctrls.hpp>	// Pascal unit
#include <Checklst.hpp>	// Pascal unit
#include <Fqbres.hpp>	// Pascal unit
#include <Fqbrcdesign.hpp>	// Pascal unit
#include <Fqbclass.hpp>	// Pascal unit
#include <Frxconnwizard.hpp>	// Pascal unit
#include <Frxcustomdbeditor.hpp>	// Pascal unit
#include <Fs_idbrtti.hpp>	// Pascal unit
#include <Frxcustomdbrtti.hpp>	// Pascal unit
#include <Frxcustomdb.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dclfrxdb14
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dclfrxdb14 */
using namespace Dclfrxdb14;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Dclfrxdb14HPP
