Cant be installed (no such db engines under lazarus):
  fs_idbreg, fs_iibxreg, fs_iadoreg, fs_ibdereg, fs_iteereg
  fs_ibdertti, fs_ichartrtti, fs_iadortti, fs_iibxrtti, 

todo for future fpc, lazarus:
  fs_idisp
