IMPORTANT:

This demo can be compiled only in the version Delphi/C++Builder 5 and higher.
(ADO components used in database connection).